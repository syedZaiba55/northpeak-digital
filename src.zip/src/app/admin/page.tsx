"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type Lead = {
  id: number;
  name: string;
  email: string;
  budget: string;
  message: string;
  status: string;
};

export default function AdminPage() {
  const [leads, setLeads] = useState<Lead[]>([]);

  useEffect(() => {
    fetchLeads();
  }, []);

  async function fetchLeads() {
    const { data, error } = await supabase
      .from("leads")
      .select("*")
      .order("id", { ascending: false });

    if (error) {
      console.error(error);
      return;
    }

    setLeads(data || []);
  }

  return (
    <main className="min-h-screen bg-slate-100 dark:bg-slate-950 p-10 text-slate-900 dark:text-white transition">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 text-slate-900 dark:text-white">
          Admin Dashboard
        </h1>

        {leads.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow p-6 border border-slate-200 dark:border-slate-700">
            <p className="text-slate-700 dark:text-slate-300">
              No leads found.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {leads.map((lead) => (
              <div
                key={lead.id}
                className="bg-white dark:bg-slate-900 rounded-xl shadow p-6 border border-slate-200 dark:border-slate-700"
              >
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
                  {lead.name}
                </h2>

                <p className="text-slate-700 dark:text-slate-300 mb-2">
                  <strong>Email:</strong> {lead.email}
                </p>

                <p className="text-slate-700 dark:text-slate-300 mb-2">
                  <strong>Budget:</strong> {lead.budget}
                </p>

                <p className="text-slate-700 dark:text-slate-300 mb-2">
                  <strong>Message:</strong> {lead.message}
                </p>

                <p className="text-slate-700 dark:text-slate-300">
                  <strong>Status:</strong> {lead.status}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}